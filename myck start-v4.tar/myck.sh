. /jd/config/config.sh
python3 /jd/config/myck_v4.py > /jd/log/myck_v4.log 2>&1
node /jd/notify.js "更新Cookies:" "$(cat /jd/log/myck_v4.log)"

import urllib.request
import random
from urllib.parse import urlencode
import requests
import time
import json
import re

requests.packages.urllib3.disable_warnings()

def getconfig():
    f = open("/jd/config/config.sh", "r")
    cks = re.findall(r"\"(pt_key=.*?;pt_pin=.*?;)\"", f.read())
    f = open("/jd/config/config.sh", "r")
    wskeys = re.findall(r"export wskeys=\"(.*?)\"", f.read())[0].split("@")
    f.close()
    return cks, wskeys

# 获取网站json数据
def get_record(url):
    resp = urllib.request.urlopen(url)
    list_json = json.loads(resp.read())
    return list_json

# 随机获取sign
def randomData():
    dataList = get_record('https://h.abcdl.cn/Code/JD/sign.json')
    max = 999 #  max 代表是你上面dataList里面的个数-1 我上面填写了6个 -1 就等于5
    index = random.randint(0, len(dataList)-1)
    print('✿ 当前使用的是第'+ str(index) + '随机sign:')
    print()
    return dataList[index]

def wstopt(cookies):
    headers = {
        'user-agent': 'okhttp/3.12.1;jdmall;android;version/10.1.2;build/89743;screen/1080x2293;os/11;network/wifi;',
        'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Cookie': cookies,
    }
    url = 'https://api.m.jd.com/client.action?functionId=genToken&' + randomData()
    body = 'body=%7B%22to%22%3A%22https%253a%252f%252fplogin.m.jd.com%252fjd-mlogin%252fstatic%252fhtml' \
           '%252fappjmp_blank.html%22%7D&'
    response = requests.post(url, headers=headers, verify=False)
    data = json.loads(response.text)
    if data.get('code') != '0':
        return None
    tokenKey = data.get('tokenKey')
    url = data.get('url')
    session = requests.session()
    params = {
        'tokenKey': tokenKey,
        'to': 'https://plogin.m.jd.com/jd-mlogin/static/html/appjmp_blank.html'
    }
    url += '?' + urlencode(params)
    session.get(url, allow_redirects=True)
    result = ""
    for k, v in session.cookies.items():
        if k == 'pt_key' or k == 'pt_pin':
            result += k + "=" + v + ";"
    return result

if __name__ == '__main__':
    cks, wskeys = getconfig()
    for i in cks:
        pin = re.findall(r"pt_(pin=.*?);", i)[0]
        for ii in wskeys:
            if pin in ii:
                try:
                    r = wstopt(ii)
                    print('✿ 当前转换后的ck为：【' + r + '】')
                    print()
                    ptck = r
                    if r == 429:
                        print("✿ 您的ip请求api过于频繁，已被流控")
                        exit()
                    else:
                        if ptck == "wskey错误":
                            print("✿ 有一个wskey可能过期了,%s" % pin)
                        elif ptck == "未知错误" or ptck == "error":
                            print("✿ 有一个wskey发生了未知错误,%s" % pin)
                        elif "</html>" in ptck:
                            print("✿ 你的ip被cloudflare拦截")
                        else:
                            with open('/jd/config/config.sh', '+r') as f:
                                t = f.read()
                                t = t.replace(i, ptck)
                                f.seek(0, 0)
                                f.write(t)
                                f.truncate()
                            print("✿ " + pin + "更新成功！")
                            print("---------------------------------")
                except:
                    print("✿ 发生了未知错误")